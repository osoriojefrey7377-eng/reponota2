[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/qoA0UW1k)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=21541382)
# 💳 Sistema de Control de Tarjeta de Crédito

## 📋 Objetivos del Ejercicio

1. **Identificar atributos y métodos** necesarios para modelar una tarjeta de crédito bancaria
2. **Implementar decisiones simples, múltiples y anidadas** para manejar las reglas del negocio bancario
3. **Aplicar validaciones y cálculos complejos** según diferentes tipos de transacciones y categorías de clientes

## 🏦 Contexto del Negocio

El banco "Confianza Total" requiere un sistema para administrar tarjetas de crédito. El sistema debe controlar límites de crédito, calcular intereses, aplicar beneficios según categorías de clientes, y gestionar diferentes tipos de transacciones con sus respectivos recargos y comisiones.

## 📜 Reglas del Negocio

### 1. Límites y Saldos
- **Límite de crédito**: Monto máximo que puede deber el cliente
- **Saldo actual**: Deuda actual del cliente con el banco
- **Cupo disponible**: límite de crédito - saldo actual

### 2. Tipos de Transacciones
| Tipo | Descripción | Recargo/Comisión |
|------|-------------|------------------|
| Compra Nacional | En Colombia | Sin recargo |
| Compra Internacional | En el exterior | 5% adicional |
| Avance en Efectivo | Retiro de cajero | $50,000 + 3% del monto |
| Pago/Abono | Reducir deuda | Cobra 2.5% interés antes del pago |

### 3. Categorías de Cliente
| Categoría | Transacciones/mes | Beneficio al pagar |
|-----------|------------------|-------------------|
| Básico | < 5 | Sin beneficios |
| Frecuente | 5-15 | $20,000 descuento si paga >50% del saldo |
| Premium | > 15 | $50,000 descuento si paga >30% del saldo |

### 4. Estados de la Tarjeta
| Estado | Condición del Cupo |
|--------|-------------------|
| Activa | > $100,000 |
| Alerta | Entre $1 y $100,000 |
| Bloqueada | ≤ $0 |

## 🎯 Objetivo 1: Identificación de Datos

Complete la siguiente tabla con los atributos necesarios:

| Atributo | Tipo de Dato | Descripción |
|----------|--------------|-------------|
| | | |
| | | |
| | | |
| | | |
| | | |
| | | |

## ✏️ Objetivo 2: Situaciones para Resolver

Resuelva las siguientes situaciones en papel antes de programar:

### Situación 1
- Límite: $2,000,000
- Saldo: $500,000
- Transacciones del mes: 3
- Operación: Compra internacional de $800,000
- **Calcule**: Nuevo saldo, categoría y estado

### Situación 2
- Límite: $3,000,000
- Saldo: $2,900,000
- Transacciones del mes: 6
- Operación: Avance en efectivo de $50,000
- **Calcule**: Si se aprueba, nuevo saldo y estado

### Situación 3
- Límite: $5,000,000
- Saldo: $3,000,000
- Transacciones del mes: 16
- Operación: Pago de $1,000,000
- **Calcule**: Intereses, beneficio aplicado y saldo final

### Situación 4
- Límite: $1,500,000
- Saldo: $1,400,000
- Transacciones del mes: 10
- Secuencia: 1) Compra nacional $80,000, 2) Pago $500,000
- **Calcule**: Estado después de cada operación

### Situación 5
- Límite: $4,000,000
- Saldo: $0
- Transacciones del mes: 0
- Secuencia: 5 compras nacionales de $200,000 c/u, luego 1 internacional de $500,000
- **Calcule**: Categoría y saldo final

## 💻 Objetivo 3: Implementación en Java

Implemente la clase `TarjetaCredito` completando todos los métodos vacíos según las reglas del negocio.

### Comandos de Ejecución

```bash
# Ejecutar pruebas unitarias
mvn test

# Ejecutar interfaz gráfica
mvn clean compile exec:java -Dexec.mainClass="edu.eam.ingesoft.fundamentos.tarjetacredito.gui.TarjetaCreditoGUI"

# Ejecutar programa de consola
mvn clean compile exec:java -Dexec.mainClass="org.example.Main"
```

## ✅ Criterios de Éxito

- [ ] Todos los tests unitarios pasan (100%)
- [ ] La GUI funciona correctamente con validaciones
- [ ] El programa de consola muestra casos de ejemplo
- [ ] Se manejan todos los tipos de transacciones
- [ ] Se calculan correctamente intereses y beneficios
- [ ] Los estados y categorías se actualizan apropiadamente

## 🚀 Pasos para Comenzar

1. Clone este repositorio
2. Abra el proyecto en IntelliJ IDEA
3. Complete la tabla de atributos en este README
4. Resuelva las situaciones en papel
5. Implemente los métodos vacíos en `TarjetaCredito.java`
6. Ejecute los tests con `mvn test`
7. Pruebe la GUI y el programa de consola
8. Haga commit y push de sus cambios

¡Éxito con el ejercicio! 💪