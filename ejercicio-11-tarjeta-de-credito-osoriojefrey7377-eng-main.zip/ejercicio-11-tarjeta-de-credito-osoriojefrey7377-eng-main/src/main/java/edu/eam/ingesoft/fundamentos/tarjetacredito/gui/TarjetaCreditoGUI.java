package edu.eam.ingesoft.fundamentos.tarjetacredito.gui;

import edu.eam.ingesoft.fundamentos.tarjetacredito.logica.TarjetaCredito;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;

/**
 * Interfaz gráfica para el sistema de tarjeta de crédito
 */
public class TarjetaCreditoGUI extends JFrame {
    
    private TarjetaCredito tarjeta;
    private DecimalFormat formatoMoneda = new DecimalFormat("$#,##0");
    
    // Componentes de la interfaz
    private JTextField txtTitular;
    private JTextField txtLimiteCredito;
    private JTextField txtMonto;
    private JComboBox<String> cmbTipoTransaccion;
    private JTextArea txtResumen;
    private JButton btnCrearTarjeta;
    private JButton btnRealizarOperacion;
    private JButton btnActualizarResumen;
    private JLabel lblSaldo;
    private JLabel lblCupo;
    private JLabel lblCategoria;
    private JLabel lblEstado;
    private JLabel lblTransacciones;
    
    // Colores corporativos
    private static final Color COLOR_PRIMARIO = new Color(0, 123, 255);
    private static final Color COLOR_EXITO = new Color(40, 167, 69);
    private static final Color COLOR_PELIGRO = new Color(220, 53, 69);
    private static final Color COLOR_ADVERTENCIA = new Color(255, 193, 7);
    private static final Color COLOR_FONDO = new Color(248, 249, 250);
    
    public TarjetaCreditoGUI() {
        inicializarVentana();
        crearComponentes();
        configurarLayout();
    }
    
    private void inicializarVentana() {
        setTitle("💳 Sistema de Tarjeta de Crédito - Banco Confianza Total");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);
        
        // Intentar configurar look and feel del sistema
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Usar look and feel por defecto
        }
    }
    
    private void crearComponentes() {
        // Inicializar campos de texto
        txtTitular = new JTextField(20);
        txtLimiteCredito = new JTextField(15);
        txtMonto = new JTextField(15);
        
        // ComboBox para tipo de transacción
        String[] tiposTransaccion = {
            "Compra Nacional",
            "Compra Internacional",
            "Avance en Efectivo",
            "Pago/Abono"
        };
        cmbTipoTransaccion = new JComboBox<>(tiposTransaccion);
        
        // Área de texto para resumen
        txtResumen = new JTextArea(10, 40);
        txtResumen.setEditable(false);
        txtResumen.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        // Botones
        btnCrearTarjeta = crearBoton("Crear Tarjeta", COLOR_PRIMARIO);
        btnRealizarOperacion = crearBoton("Realizar Operación", COLOR_EXITO);
        btnActualizarResumen = crearBoton("Actualizar Resumen", COLOR_PRIMARIO);
        
        // Labels informativos
        lblSaldo = new JLabel("Saldo: $0");
        lblCupo = new JLabel("Cupo: $0");
        lblCategoria = new JLabel("Categoría: -");
        lblEstado = new JLabel("Estado: -");
        lblTransacciones = new JLabel("Transacciones: 0");
        
        // Configurar eventos
        configurarEventos();
        
        // Estado inicial
        btnRealizarOperacion.setEnabled(false);
        btnActualizarResumen.setEnabled(false);
    }
    
    private JButton crearBoton(String texto, Color color) {
        JButton boton = new JButton(texto);
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setOpaque(true);
        boton.setFont(new Font("Arial", Font.BOLD, 12));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent e) {
                boton.setBackground(color);
            }
        });
        
        return boton;
    }
    
    private void configurarLayout() {
        setLayout(new BorderLayout(10, 10));
        
        // Panel superior - Creación de tarjeta
        JPanel panelSuperior = new JPanel(new GridBagLayout());
        panelSuperior.setBackground(Color.WHITE);
        panelSuperior.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(COLOR_PRIMARIO, 2),
                "Crear Nueva Tarjeta",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                COLOR_PRIMARIO
            ),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        panelSuperior.add(new JLabel("Titular:"), gbc);
        gbc.gridx = 1;
        panelSuperior.add(txtTitular, gbc);
        
        gbc.gridx = 2;
        panelSuperior.add(new JLabel("Límite de Crédito:"), gbc);
        gbc.gridx = 3;
        panelSuperior.add(txtLimiteCredito, gbc);
        
        gbc.gridx = 4;
        panelSuperior.add(btnCrearTarjeta, gbc);
        
        // Panel central - Operaciones y estado
        JPanel panelCentral = new JPanel(new GridLayout(1, 2, 10, 10));
        panelCentral.setBackground(COLOR_FONDO);
        
        // Panel de operaciones
        JPanel panelOperaciones = new JPanel(new GridBagLayout());
        panelOperaciones.setBackground(Color.WHITE);
        panelOperaciones.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(COLOR_EXITO, 2),
                "Realizar Transacción",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                COLOR_EXITO
            ),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 5, 10, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        gbc.gridx = 0; gbc.gridy = 0;
        panelOperaciones.add(new JLabel("Tipo de Transacción:"), gbc);
        gbc.gridy = 1;
        panelOperaciones.add(cmbTipoTransaccion, gbc);
        
        gbc.gridy = 2;
        panelOperaciones.add(new JLabel("Monto:"), gbc);
        gbc.gridy = 3;
        panelOperaciones.add(txtMonto, gbc);
        
        gbc.gridy = 4;
        gbc.insets = new Insets(20, 5, 10, 5);
        panelOperaciones.add(btnRealizarOperacion, gbc);
        
        // Panel de estado
        JPanel panelEstado = new JPanel(new GridBagLayout());
        panelEstado.setBackground(Color.WHITE);
        panelEstado.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(COLOR_ADVERTENCIA, 2),
                "Estado de la Tarjeta",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                COLOR_ADVERTENCIA
            ),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0; gbc.gridy = 0;
        
        Font fontEstado = new Font("Arial", Font.BOLD, 13);
        lblSaldo.setFont(fontEstado);
        lblCupo.setFont(fontEstado);
        lblCategoria.setFont(fontEstado);
        lblEstado.setFont(fontEstado);
        lblTransacciones.setFont(fontEstado);
        
        panelEstado.add(lblSaldo, gbc);
        gbc.gridy = 1;
        panelEstado.add(lblCupo, gbc);
        gbc.gridy = 2;
        panelEstado.add(lblCategoria, gbc);
        gbc.gridy = 3;
        panelEstado.add(lblEstado, gbc);
        gbc.gridy = 4;
        panelEstado.add(lblTransacciones, gbc);
        gbc.gridy = 5;
        gbc.insets = new Insets(20, 10, 8, 10);
        panelEstado.add(btnActualizarResumen, gbc);
        
        panelCentral.add(panelOperaciones);
        panelCentral.add(panelEstado);
        
        // Panel inferior - Resumen
        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.setBackground(Color.WHITE);
        panelInferior.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(COLOR_PRIMARIO, 2),
                "Resumen de Cuenta",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                COLOR_PRIMARIO
            ),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        JScrollPane scrollResumen = new JScrollPane(txtResumen);
        panelInferior.add(scrollResumen, BorderLayout.CENTER);
        
        // Agregar paneles a la ventana
        JPanel contenedorPrincipal = new JPanel(new BorderLayout(10, 10));
        contenedorPrincipal.setBackground(COLOR_FONDO);
        contenedorPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        contenedorPrincipal.add(panelSuperior, BorderLayout.NORTH);
        contenedorPrincipal.add(panelCentral, BorderLayout.CENTER);
        contenedorPrincipal.add(panelInferior, BorderLayout.SOUTH);
        
        add(contenedorPrincipal);
    }
    
    private void configurarEventos() {
        btnCrearTarjeta.addActionListener(e -> crearTarjeta());
        btnRealizarOperacion.addActionListener(e -> realizarOperacion());
        btnActualizarResumen.addActionListener(e -> actualizarResumen());
    }
    
    private void crearTarjeta() {
        try {
            String titular = txtTitular.getText().trim();
            if (titular.isEmpty()) {
                mostrarError("Por favor ingrese el nombre del titular");
                return;
            }
            
            double limite = Double.parseDouble(txtLimiteCredito.getText());
            if (limite <= 0) {
                mostrarError("El límite de crédito debe ser mayor a 0");
                return;
            }
            
            tarjeta = new TarjetaCredito(titular, limite);
            
            btnRealizarOperacion.setEnabled(true);
            btnActualizarResumen.setEnabled(true);
            btnCrearTarjeta.setEnabled(false);
            txtTitular.setEditable(false);
            txtLimiteCredito.setEditable(false);
            
            actualizarEstado();
            mostrarMensaje("Tarjeta creada exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException ex) {
            mostrarError("Por favor ingrese un límite de crédito válido");
        }
    }
    
    private void realizarOperacion() {
        if (tarjeta == null) {
            mostrarError("Primero debe crear una tarjeta");
            return;
        }
        
        try {
            double monto = Double.parseDouble(txtMonto.getText());
            if (monto <= 0) {
                mostrarError("El monto debe ser mayor a 0");
                return;
            }
            
            String tipoOperacion = (String) cmbTipoTransaccion.getSelectedItem();
            boolean resultado = false;
            String mensaje = "";
            
            switch (tipoOperacion) {
                case "Compra Nacional":
                    resultado = tarjeta.realizarCompra(monto, "NACIONAL");
                    mensaje = resultado ? 
                        "Compra nacional aprobada por " + formatoMoneda.format(monto) :
                        "Compra nacional rechazada - Cupo insuficiente";
                    break;
                    
                case "Compra Internacional":
                    resultado = tarjeta.realizarCompra(monto, "INTERNACIONAL");
                    double montoConRecargo = monto * 1.05;
                    mensaje = resultado ? 
                        "Compra internacional aprobada\nMonto original: " + formatoMoneda.format(monto) +
                        "\nMonto con recargo (5%): " + formatoMoneda.format(montoConRecargo) :
                        "Compra internacional rechazada - Cupo insuficiente para " + 
                        formatoMoneda.format(montoConRecargo);
                    break;
                    
                case "Avance en Efectivo":
                    resultado = tarjeta.realizarCompra(monto, "AVANCE_EFECTIVO");
                    double costoTotal = monto + 50000 + (monto * 0.03);
                    mensaje = resultado ? 
                        "Avance en efectivo aprobado\nMonto retirado: " + formatoMoneda.format(monto) +
                        "\nCosto total: " + formatoMoneda.format(costoTotal) :
                        "Avance rechazado - Cupo insuficiente para " + formatoMoneda.format(costoTotal);
                    break;
                    
                case "Pago/Abono":
                    double saldoAnterior = tarjeta.getSaldoActual();
                    boolean pagoExitoso = tarjeta.realizarPago(monto);
                    if (pagoExitoso) {
                        mensaje = "Pago procesado exitosamente\n" +
                                 "Saldo anterior: " + formatoMoneda.format(saldoAnterior) +
                                 "\nPago realizado: " + formatoMoneda.format(monto) +
                                 "\nNuevo saldo: " + formatoMoneda.format(tarjeta.getSaldoActual());
                    } else {
                        mensaje = "Pago rechazado\n" +
                                 "No hay deuda o el monto excede el saldo con intereses";
                    }
                    resultado = true;
                    break;
            }
            
            actualizarEstado();
            
            if (resultado) {
                mostrarMensaje(mensaje, "Operación Exitosa", JOptionPane.INFORMATION_MESSAGE);
            } else {
                mostrarError(mensaje);
            }
            
            txtMonto.setText("");
            
        } catch (NumberFormatException ex) {
            mostrarError("Por favor ingrese un monto válido");
        }
    }
    
    private void actualizarEstado() {
        if (tarjeta == null) return;
        
        lblSaldo.setText("Saldo: " + formatoMoneda.format(tarjeta.getSaldoActual()));
        lblCupo.setText("Cupo: " + formatoMoneda.format(tarjeta.obtenerCupoDisponible()));
        lblCategoria.setText("Categoría: " + tarjeta.obtenerCategoria());
        lblTransacciones.setText("Transacciones: " + tarjeta.getTransaccionesMes());
        
        String estado = tarjeta.obtenerEstado();
        lblEstado.setText("Estado: " + estado);
        
        // Cambiar color según estado
        switch (estado) {
            case "ACTIVA":
                lblEstado.setForeground(COLOR_EXITO);
                break;
            case "ALERTA":
                lblEstado.setForeground(COLOR_ADVERTENCIA);
                break;
            case "BLOQUEADA":
                lblEstado.setForeground(COLOR_PELIGRO);
                break;
        }
    }
    
    private void actualizarResumen() {
        if (tarjeta == null) {
            mostrarError("Primero debe crear una tarjeta");
            return;
        }
        
        txtResumen.setText(tarjeta.mostrarResumenCuenta());
    }
    
    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void mostrarMensaje(String mensaje, String titulo, int tipo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, tipo);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TarjetaCreditoGUI gui = new TarjetaCreditoGUI();
            gui.setVisible(true);
        });
    }
}