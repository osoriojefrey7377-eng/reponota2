package edu.eam.ingesoft.fundamentos.tarjetacredito.logica;

public class TarjetaCredito {

    // Atributos privados
    private final String titular;
    private final double limiteCredito;
    private double saldoActual;
    private int transaccionesMes;

    // Constantes para los cálculos
    public static final double RECARGO_INTERNACIONAL = 0.05;
    public static final double COMISION_FIJA_AVANCE = 50000;
    public static final double COMISION_PORCENTAJE_AVANCE = 0.03;
    public static final double INTERES_PAGO = 0.025;
    public static final double BENEFICIO_FRECUENTE = 20000;
    public static final double BENEFICIO_PREMIUM = 50000;
    public static final double LIMITE_ESTADO_ACTIVA = 100000;

    /**
     * Constructor de la tarjeta de crédito
     * @param titular Nombre del titular de la tarjeta
     * @param limiteCredito Límite máximo de crédito
     */
    public TarjetaCredito(String titular, double limiteCredito) {
        this.titular = titular;
        this.limiteCredito = limiteCredito;
        this.saldoActual = 0;
        this.transaccionesMes = 0;
    }

    /**
     * Método central para realizar compras según el tipo especificado
     * @param monto Valor de la compra
     * @param tipoCompra Tipo de compra: "NACIONAL", "INTERNACIONAL", "AVANCE_EFECTIVO"
     * @return true si la compra fue aprobada, false si fue rechazada
     */
    public boolean realizarCompra(double monto, String tipoCompra) {
        double montoTotal = monto;

        // Ajustar monto según tipo de compra
        switch (tipoCompra) {
            case "INTERNACIONAL":
                montoTotal += monto * RECARGO_INTERNACIONAL;
                break;
            case "AVANCE_EFECTIVO":
                montoTotal += COMISION_FIJA_AVANCE + (monto * COMISION_PORCENTAJE_AVANCE);
                break;
            case "NACIONAL":
                break;
            default:
                return false; // tipo inválido
        }

        // Verificar si hay cupo suficiente
        if (saldoActual + montoTotal > limiteCredito) {
            return false; // compra rechazada por falta de cupo
        }

        // Registrar compra
        saldoActual += montoTotal;
        transaccionesMes++;
        return true;
    }

    /** Compra nacional */
    public boolean realizarCompraNacional(double monto) {
        return realizarCompra(monto, "NACIONAL");
    }

    /** Compra internacional */
    public boolean realizarCompraInternacional(double monto) {
        return realizarCompra(monto, "INTERNACIONAL");
    }

    /** Avance en efectivo */
    public boolean realizarAvanceEfectivo(double monto) {
        return realizarCompra(monto, "AVANCE_EFECTIVO");
    }

    /**
     * Realiza un pago para reducir la deuda
     * @param monto Cantidad a pagar
     * @return true si el pago fue exitoso, false si fue rechazado
     */
    public boolean realizarPago(double monto) {
        if (monto <= 0 || saldoActual == 0) {
            return false;
        }

        // Aplicar beneficio según categoría antes del pago
        String categoria = obtenerCategoria();
        if (categoria.equals("FRECUENTE")) {
            saldoActual -= BENEFICIO_FRECUENTE;
        } else if (categoria.equals("PREMIUM")) {
            saldoActual -= BENEFICIO_PREMIUM;
        }

        // Aplicar pago
        saldoActual -= monto;

        // Si el saldo se vuelve negativo, aplicar interés (simula pago adelantado)
        if (saldoActual < 0) {
            saldoActual = 0;
        } else {
            saldoActual += saldoActual * INTERES_PAGO;
        }

        return true;
    }

    /** Cupo disponible */
    public double obtenerCupoDisponible() {
        return limiteCredito - saldoActual;
    }

    /**
     * Determina la categoría del cliente según uso mensual
     * @return "BASICO", "FRECUENTE" o "PREMIUM"
     */
    public String obtenerCategoria() {
        if (transaccionesMes >= 10) {
            return "PREMIUM";
        } else if (transaccionesMes >= 5) {
            return "FRECUENTE";
        } else {
            return "BASICO";
        }
    }

    /**
     * Determina el estado actual de la tarjeta
     * @return "ACTIVA", "ALERTA" o "BLOQUEADA"
     */
    public String obtenerEstado() {
        double cupoDisponible = obtenerCupoDisponible();

        if (cupoDisponible >= LIMITE_ESTADO_ACTIVA) {
            return "ACTIVA";
        } else if (cupoDisponible > 0) {
            return "ALERTA";
        } else {
            return "BLOQUEADA";
        }
    }

    /** Muestra resumen completo */
    public String mostrarResumenCuenta() {
        return "=================================\n" +
                "    RESUMEN DE CUENTA    \n" +
                "=================================\n" +
                String.format("Titular: %s\n", titular) +
                String.format("Límite de crédito: $%,.0f\n", limiteCredito) +
                String.format("Saldo actual: $%,.0f\n", saldoActual) +
                String.format("Cupo disponible: $%,.0f\n", obtenerCupoDisponible()) +
                String.format("Categoría: %s\n", obtenerCategoria()) +
                String.format("Estado: %s\n", obtenerEstado()) +
                String.format("Transacciones del mes: %d\n", transaccionesMes) +
                "=================================\n";
    }

    // Getters y Setters
    public String getTitular() {
        return titular;
    }

    public double getLimiteCredito() {
        return limiteCredito;
    }

    public double getSaldoActual() {
        return saldoActual;
    }

    public void setSaldoActual(double saldoActual) {
        this.saldoActual = saldoActual;
    }

    public int getTransaccionesMes() {
        return transaccionesMes;
    }

    public void setTransaccionesMes(int transaccionesMes) {
        this.transaccionesMes = transaccionesMes;
    }
}