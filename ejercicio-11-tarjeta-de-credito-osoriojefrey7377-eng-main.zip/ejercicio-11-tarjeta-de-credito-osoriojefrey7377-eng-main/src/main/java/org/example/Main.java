package org.example;

import edu.eam.ingesoft.fundamentos.tarjetacredito.logica.TarjetaCredito;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * Programa principal para demostrar el uso de la tarjeta de crédito
 */
public class Main {
    
    private static final DecimalFormat formatoMoneda = new DecimalFormat("$#,##0");
    private static final Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        System.out.println("=====================================");
        System.out.println("   SISTEMA DE TARJETA DE CRÉDITO    ");
        System.out.println("      BANCO CONFIANZA TOTAL          ");
        System.out.println("=====================================\n");
        
        // Demostrar casos de ejemplo
        demostrarCasosEjemplo();
        
        // Modo interactivo
        System.out.println("\n¿Desea ejecutar el modo interactivo? (S/N):");
        String respuesta = scanner.nextLine();
        
        if (respuesta.equalsIgnoreCase("S")) {
            modoInteractivo();
        }
        
        System.out.println("\n¡Gracias por usar el sistema!");
    }
    
    private static void demostrarCasosEjemplo() {
        System.out.println("DEMOSTRANDO CASOS DE EJEMPLO");
        System.out.println("=============================\n");
        
        // Caso 1: María González - Compra internacional
        System.out.println("CASO 1: María González - Compra Internacional");
        System.out.println("----------------------------------------------");
        TarjetaCredito tarjetaMaria = new TarjetaCredito("María González", 3000000);
        tarjetaMaria.setSaldoActual(1200000);
        tarjetaMaria.setTransaccionesMes(8);
        
        System.out.println("Situación inicial:");
        System.out.println("- Límite: " + formatoMoneda.format(3000000));
        System.out.println("- Saldo actual: " + formatoMoneda.format(1200000));
        System.out.println("- Transacciones: 8");
        System.out.println("- Categoría: " + tarjetaMaria.obtenerCategoria());
        
        System.out.println("\nRealizando compra internacional de $500,000...");
        boolean resultado = tarjetaMaria.realizarCompraInternacional(500000);
        
        if (resultado) {
            System.out.println("✓ Compra APROBADA");
            System.out.println("- Monto con recargo (5%): " + formatoMoneda.format(525000));
            System.out.println("- Nuevo saldo: " + formatoMoneda.format(tarjetaMaria.getSaldoActual()));
            System.out.println("- Cupo disponible: " + formatoMoneda.format(tarjetaMaria.obtenerCupoDisponible()));
            System.out.println("- Estado: " + tarjetaMaria.obtenerEstado());
        } else {
            System.out.println("✗ Compra RECHAZADA - Cupo insuficiente");
        }
        
        // Caso 2: Carlos Ruiz - Pago con beneficio Premium
        System.out.println("\n\nCASO 2: Carlos Ruiz - Pago con Beneficio Premium");
        System.out.println("-------------------------------------------------");
        TarjetaCredito tarjetaCarlos = new TarjetaCredito("Carlos Ruiz", 5000000);
        tarjetaCarlos.setSaldoActual(3500000);
        tarjetaCarlos.setTransaccionesMes(18);
        
        System.out.println("Situación inicial:");
        System.out.println("- Límite: " + formatoMoneda.format(5000000));
        System.out.println("- Saldo actual: " + formatoMoneda.format(3500000));
        System.out.println("- Transacciones: 18");
        System.out.println("- Categoría: " + tarjetaCarlos.obtenerCategoria() + " (tiene beneficios)");
        
        System.out.println("\nRealizando pago de $1,500,000...");
        double saldoAnterior = tarjetaCarlos.getSaldoActual();
        boolean pagoExitoso = tarjetaCarlos.realizarPago(1500000);

        if (pagoExitoso) {
            System.out.println("✓ Pago procesado");
            System.out.println("- Intereses aplicados (2.5%): " + formatoMoneda.format(saldoAnterior * 0.025));
            System.out.println("- Beneficio Premium aplicado: " + formatoMoneda.format(50000));
            System.out.println("- Nuevo saldo: " + formatoMoneda.format(tarjetaCarlos.getSaldoActual()));
        } else {
            System.out.println("✗ Pago rechazado");
        }
        System.out.println("- Cupo disponible: " + formatoMoneda.format(tarjetaCarlos.obtenerCupoDisponible()));
        
        // Caso 3: Ana López - Avance rechazado
        System.out.println("\n\nCASO 3: Ana López - Avance en Efectivo Rechazado");
        System.out.println("-------------------------------------------------");
        TarjetaCredito tarjetaAna = new TarjetaCredito("Ana López", 2000000);
        tarjetaAna.setSaldoActual(1850000);
        tarjetaAna.setTransaccionesMes(3);
        
        System.out.println("Situación inicial:");
        System.out.println("- Límite: " + formatoMoneda.format(2000000));
        System.out.println("- Saldo actual: " + formatoMoneda.format(1850000));
        System.out.println("- Cupo disponible: " + formatoMoneda.format(tarjetaAna.obtenerCupoDisponible()));
        System.out.println("- Categoría: " + tarjetaAna.obtenerCategoria());
        
        System.out.println("\nSolicitando avance en efectivo de $100,000...");
        double costoAvance = 100000 + 50000 + (100000 * 0.03);
        System.out.println("- Costo total del avance: " + formatoMoneda.format(costoAvance));
        
        boolean resultadoAvance = tarjetaAna.realizarAvanceEfectivo(100000);
        
        if (!resultadoAvance) {
            System.out.println("✗ Avance RECHAZADO");
            System.out.println("- Motivo: Cupo insuficiente");
            System.out.println("- Cupo disponible: " + formatoMoneda.format(tarjetaAna.obtenerCupoDisponible()));
            System.out.println("- Monto requerido: " + formatoMoneda.format(costoAvance));
        }
        
        // Caso 4: Cambio de estado
        System.out.println("\n\nCASO 4: Luis Pérez - Cambio de Estado a ALERTA");
        System.out.println("------------------------------------------------");
        TarjetaCredito tarjetaLuis = new TarjetaCredito("Luis Pérez", 4000000);
        tarjetaLuis.setSaldoActual(3920000);
        tarjetaLuis.setTransaccionesMes(7);
        
        System.out.println("Situación inicial:");
        System.out.println("- Límite: " + formatoMoneda.format(4000000));
        System.out.println("- Saldo actual: " + formatoMoneda.format(3920000));
        System.out.println("- Cupo disponible: " + formatoMoneda.format(tarjetaLuis.obtenerCupoDisponible()));
        System.out.println("- Estado actual: " + tarjetaLuis.obtenerEstado());
        
        System.out.println("\nRealizando compra nacional de $75,000...");
        boolean resultadoCompra = tarjetaLuis.realizarCompraNacional(75000);
        
        if (resultadoCompra) {
            System.out.println("✓ Compra APROBADA");
            System.out.println("- Nuevo saldo: " + formatoMoneda.format(tarjetaLuis.getSaldoActual()));
            System.out.println("- Cupo disponible: " + formatoMoneda.format(tarjetaLuis.obtenerCupoDisponible()));
            System.out.println("- NUEVO ESTADO: " + tarjetaLuis.obtenerEstado() + " ⚠️");
            System.out.println("- Advertencia: Cupo muy bajo, próximo a bloquearse");
        }
    }
    
    private static void modoInteractivo() {
        System.out.println("\n=====================================");
        System.out.println("        MODO INTERACTIVO             ");
        System.out.println("=====================================\n");
        
        System.out.print("Ingrese el nombre del titular: ");
        String titular = scanner.nextLine();
        
        System.out.print("Ingrese el límite de crédito: ");
        double limite = scanner.nextDouble();
        scanner.nextLine(); // Limpiar buffer
        
        TarjetaCredito tarjeta = new TarjetaCredito(titular, limite);
        
        boolean continuar = true;
        while (continuar) {
            System.out.println("\n--- MENÚ DE OPCIONES ---");
            System.out.println("1. Compra Nacional");
            System.out.println("2. Compra Internacional");
            System.out.println("3. Avance en Efectivo");
            System.out.println("4. Realizar Pago");
            System.out.println("5. Ver Resumen de Cuenta");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            
            switch (opcion) {
                case 1:
                    realizarCompraNacional(tarjeta);
                    break;
                case 2:
                    realizarCompraInternacional(tarjeta);
                    break;
                case 3:
                    realizarAvanceEfectivo(tarjeta);
                    break;
                case 4:
                    realizarPago(tarjeta);
                    break;
                case 5:
                    System.out.println(tarjeta.mostrarResumenCuenta());
                    break;
                case 6:
                    continuar = false;
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }
    
    private static void realizarCompraNacional(TarjetaCredito tarjeta) {
        System.out.print("Ingrese el monto de la compra: ");
        double monto = scanner.nextDouble();
        scanner.nextLine();
        
        if (tarjeta.realizarCompraNacional(monto)) {
            System.out.println("✓ Compra nacional aprobada");
            System.out.println("Nuevo saldo: " + formatoMoneda.format(tarjeta.getSaldoActual()));
        } else {
            System.out.println("✗ Compra rechazada - Cupo insuficiente");
        }
    }
    
    private static void realizarCompraInternacional(TarjetaCredito tarjeta) {
        System.out.print("Ingrese el monto de la compra: ");
        double monto = scanner.nextDouble();
        scanner.nextLine();
        
        if (tarjeta.realizarCompraInternacional(monto)) {
            System.out.println("✓ Compra internacional aprobada");
            System.out.println("Monto con recargo (5%): " + formatoMoneda.format(monto * 1.05));
            System.out.println("Nuevo saldo: " + formatoMoneda.format(tarjeta.getSaldoActual()));
        } else {
            System.out.println("✗ Compra rechazada - Cupo insuficiente");
        }
    }
    
    private static void realizarAvanceEfectivo(TarjetaCredito tarjeta) {
        System.out.print("Ingrese el monto a retirar: ");
        double monto = scanner.nextDouble();
        scanner.nextLine();
        
        if (tarjeta.realizarAvanceEfectivo(monto)) {
            double costoTotal = monto + 50000 + (monto * 0.03);
            System.out.println("✓ Avance en efectivo aprobado");
            System.out.println("Costo total: " + formatoMoneda.format(costoTotal));
            System.out.println("Nuevo saldo: " + formatoMoneda.format(tarjeta.getSaldoActual()));
        } else {
            System.out.println("✗ Avance rechazado - Cupo insuficiente");
        }
    }
    
    private static void realizarPago(TarjetaCredito tarjeta) {
        System.out.print("Ingrese el monto del pago: ");
        double monto = scanner.nextDouble();
        scanner.nextLine();

        double saldoAnterior = tarjeta.getSaldoActual();
        boolean pagoExitoso = tarjeta.realizarPago(monto);

        if (pagoExitoso) {
            System.out.println("✓ Pago procesado");
            System.out.println("Saldo anterior: " + formatoMoneda.format(saldoAnterior));
        } else {
            System.out.println("✗ Pago rechazado - No hay deuda o el monto excede el saldo con intereses");
        }
        
        if (saldoAnterior > 0) {
            System.out.println("Intereses aplicados (2.5%): " + formatoMoneda.format(saldoAnterior * 0.025));
        }
        
        String categoria = tarjeta.obtenerCategoria();
        if (!categoria.equals("BASICO")) {
            System.out.println("Categoría: " + categoria + " (puede tener beneficios)");
        }

        System.out.println("Nuevo saldo: " + formatoMoneda.format(tarjeta.getSaldoActual()));
    }
}