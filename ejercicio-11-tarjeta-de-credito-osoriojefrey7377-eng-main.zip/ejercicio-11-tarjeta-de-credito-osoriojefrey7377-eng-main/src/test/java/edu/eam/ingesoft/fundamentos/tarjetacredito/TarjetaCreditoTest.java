package edu.eam.ingesoft.fundamentos.tarjetacredito;

import edu.eam.ingesoft.fundamentos.tarjetacredito.logica.TarjetaCredito;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para la clase TarjetaCredito
 */
public class TarjetaCreditoTest {
    
    private TarjetaCredito tarjeta;
    private static final double DELTA = 0.01; // Para comparaciones de decimales
    
    @BeforeEach
    void setUp() {
        tarjeta = new TarjetaCredito("Juan Pérez", 5000000);
    }
    
    @Test
    @DisplayName("Test 1: Crear tarjeta nueva - debe inicializar correctamente")
    void testCrearTarjeta() {
        assertEquals("Juan Pérez", tarjeta.getTitular());
        assertEquals(5000000, tarjeta.getLimiteCredito(), DELTA);
        assertEquals(0, tarjeta.getSaldoActual(), DELTA);
        assertEquals(0, tarjeta.getTransaccionesMes());
        assertEquals(5000000, tarjeta.obtenerCupoDisponible(), DELTA);
    }
    
    @Test
    @DisplayName("Test 2: Compra nacional exitosa")
    void testCompraNacionalExitosa() {
        boolean resultado = tarjeta.realizarCompra(500000, "NACIONAL");
        
        assertTrue(resultado);
        assertEquals(500000, tarjeta.getSaldoActual(), DELTA);
        assertEquals(1, tarjeta.getTransaccionesMes());
        assertEquals(4500000, tarjeta.obtenerCupoDisponible(), DELTA);
    }
    
    @Test
    @DisplayName("Test 3: Compra nacional rechazada por falta de cupo")
    void testCompraNacionalRechazada() {
        tarjeta.setSaldoActual(4900000);
        
        boolean resultado = tarjeta.realizarCompra(200000, "NACIONAL");
        
        assertFalse(resultado);
        assertEquals(4900000, tarjeta.getSaldoActual(), DELTA);
        assertEquals(0, tarjeta.getTransaccionesMes());
    }
    
    @Test
    @DisplayName("Test 4: Compra internacional con recargo del 5%")
    void testCompraInternacional() {
        boolean resultado = tarjeta.realizarCompra(1000000, "INTERNACIONAL");
        
        assertTrue(resultado);
        assertEquals(1050000, tarjeta.getSaldoActual(), DELTA); // 1000000 + 5%
        assertEquals(1, tarjeta.getTransaccionesMes());
        assertEquals(3950000, tarjeta.obtenerCupoDisponible(), DELTA);
    }
    
    @Test
    @DisplayName("Test 5: Avance en efectivo con comisiones")
    void testAvanceEfectivo() {
        boolean resultado = tarjeta.realizarCompra(1000000, "AVANCE_EFECTIVO");
        
        assertTrue(resultado);
        // 1000000 + 50000 + (1000000 * 0.03) = 1000000 + 50000 + 30000 = 1080000
        assertEquals(1080000, tarjeta.getSaldoActual(), DELTA);
        assertEquals(1, tarjeta.getTransaccionesMes());
    }
    
    @Test
    @DisplayName("Test 6: Pago con intereses")
    void testPagoConIntereses() {
        tarjeta.setSaldoActual(1000000);

        boolean resultado = tarjeta.realizarPago(500000);

        // Saldo con intereses: 1000000 * 1.025 = 1025000
        // Después del pago: 1025000 - 500000 = 525000
        assertTrue(resultado);
        assertEquals(525000, tarjeta.getSaldoActual(), DELTA);
        assertEquals(0, tarjeta.getTransaccionesMes()); // Pagos no incrementan transacciones
    }
    
    @Test
    @DisplayName("Test 7: Categoría BASICO con menos de 5 transacciones")
    void testCategoriaBasico() {
        tarjeta.setTransaccionesMes(3);
        assertEquals("BASICO", tarjeta.obtenerCategoria());
    }
    
    @Test
    @DisplayName("Test 8: Categoría FRECUENTE entre 5 y 15 transacciones")
    void testCategoriaFrecuente() {
        tarjeta.setTransaccionesMes(10);
        assertEquals("FRECUENTE", tarjeta.obtenerCategoria());
    }
    
    @Test
    @DisplayName("Test 9: Categoría PREMIUM con más de 15 transacciones")
    void testCategoriaPremium() {
        tarjeta.setTransaccionesMes(20);
        assertEquals("PREMIUM", tarjeta.obtenerCategoria());
    }
    
    @Test
    @DisplayName("Test 10: Estado ACTIVA con cupo mayor a $100,000")
    void testEstadoActiva() {
        tarjeta.setSaldoActual(4000000);
        // Cupo: 5000000 - 4000000 = 1000000
        assertEquals("ACTIVA", tarjeta.obtenerEstado());
    }
    
    @Test
    @DisplayName("Test 11: Estado ALERTA con cupo entre $1 y $100,000")
    void testEstadoAlerta() {
        tarjeta.setSaldoActual(4950000);
        // Cupo: 5000000 - 4950000 = 50000
        assertEquals("ALERTA", tarjeta.obtenerEstado());
    }
    
    @Test
    @DisplayName("Test 12: Estado BLOQUEADA con cupo $0 o negativo")
    void testEstadoBloqueada() {
        tarjeta.setSaldoActual(5000000);
        // Cupo: 5000000 - 5000000 = 0
        assertEquals("BLOQUEADA", tarjeta.obtenerEstado());
    }
    
    @Test
    @DisplayName("Test 13: Beneficio FRECUENTE al pagar más del 50%")
    void testBeneficioFrecuente() {
        tarjeta.setSaldoActual(1000000);
        tarjeta.setTransaccionesMes(10); // Categoría FRECUENTE

        boolean resultado = tarjeta.realizarPago(600000);

        // Saldo con intereses: 1000000 * 1.025 = 1025000
        // Pago de 600000 es el 58.5% del saldo con intereses
        // Después del pago: 1025000 - 600000 = 425000
        // Con beneficio: 425000 - 20000 = 405000
        assertTrue(resultado);
        assertEquals(405000, tarjeta.getSaldoActual(), DELTA);
    }
    
    @Test
    @DisplayName("Test 14: Beneficio PREMIUM al pagar más del 30%")
    void testBeneficioPremium() {
        tarjeta.setSaldoActual(2000000);
        tarjeta.setTransaccionesMes(18); // Categoría PREMIUM

        boolean resultado = tarjeta.realizarPago(700000);

        // Saldo con intereses: 2000000 * 1.025 = 2050000
        // Pago de 700000 es el 34.1% del saldo con intereses
        // Después del pago: 2050000 - 700000 = 1350000
        // Con beneficio: 1350000 - 50000 = 1300000
        assertTrue(resultado);
        assertEquals(1300000, tarjeta.getSaldoActual(), DELTA);
    }
    
    @Test
    @DisplayName("Test 15: Múltiples transacciones secuenciales")
    void testMultiplesTransacciones() {
        // Compra nacional
        assertTrue(tarjeta.realizarCompra(500000, "NACIONAL"));
        assertEquals(1, tarjeta.getTransaccionesMes());
        
        // Compra internacional
        assertTrue(tarjeta.realizarCompra(1000000, "INTERNACIONAL"));
        assertEquals(2, tarjeta.getTransaccionesMes());
        
        // Saldo actual: 500000 + 1050000 = 1550000
        assertEquals(1550000, tarjeta.getSaldoActual(), DELTA);
        
        // Avance en efectivo
        assertTrue(tarjeta.realizarCompra(500000, "AVANCE_EFECTIVO"));
        assertEquals(3, tarjeta.getTransaccionesMes());
        
        // Saldo: 1550000 + 500000 + 50000 + 15000 = 2115000
        assertEquals(2115000, tarjeta.getSaldoActual(), DELTA);
        
        // Cupo disponible: 5000000 - 2115000 = 2885000
        assertEquals(2885000, tarjeta.obtenerCupoDisponible(), DELTA);
        assertEquals("ACTIVA", tarjeta.obtenerEstado());
    }
    
    @Test
    @DisplayName("Test 16: Compra internacional rechazada por cupo insuficiente")
    void testCompraInternacionalRechazadaCupo() {
        tarjeta.setSaldoActual(4900000);
        
        // Intento de compra de $100000, con recargo sería $105000
        // Cupo disponible: 5000000 - 4900000 = 100000 (insuficiente para 105000)
        boolean resultado = tarjeta.realizarCompra(100000, "INTERNACIONAL");
        
        assertFalse(resultado);
        assertEquals(4900000, tarjeta.getSaldoActual(), DELTA);
        assertEquals(0, tarjeta.getTransaccionesMes());
    }
    
    @Test
    @DisplayName("Test 17: Avance en efectivo rechazado cerca del límite")
    void testAvanceRechazadoCercaLimite() {
        tarjeta.setSaldoActual(4850000);
        
        // Avance de $100000: costo total = 100000 + 50000 + 3000 = 153000
        // Cupo disponible: 5000000 - 4850000 = 150000 (insuficiente)
        boolean resultado = tarjeta.realizarCompra(100000, "AVANCE_EFECTIVO");
        
        assertFalse(resultado);
        assertEquals(4850000, tarjeta.getSaldoActual(), DELTA);
    }
    
    @Test
    @DisplayName("Test 18: Pago mayor al saldo debe ser rechazado")
    void testPagoMayorAlSaldo() {
        tarjeta.setSaldoActual(100000);

        boolean resultado = tarjeta.realizarPago(200000);

        // Saldo con intereses: 100000 * 1.025 = 102500
        // Pago de 200000 > 102500, debe ser rechazado
        assertFalse(resultado);
        // El saldo no debe modificarse si el pago es rechazado
        assertEquals(100000, tarjeta.getSaldoActual(), DELTA);
    }

    @Test
    @DisplayName("Test 22: No se puede pagar si no hay deuda")
    void testPagoSinDeuda() {
        tarjeta.setSaldoActual(0);

        boolean resultado = tarjeta.realizarPago(50000);

        assertFalse(resultado);
        assertEquals(0, tarjeta.getSaldoActual(), DELTA);
    }
    
    @Test
    @DisplayName("Test 19: Resumen de cuenta formateado correctamente")
    void testMostrarResumenCuenta() {
        tarjeta.setSaldoActual(2500000);
        tarjeta.setTransaccionesMes(7);
        
        String resumen = tarjeta.mostrarResumenCuenta();
        
        assertNotNull(resumen);
        assertTrue(resumen.contains("Juan Pérez"));
        // Verificar que contiene los números sin importar el formato
        assertTrue(resumen.contains("5000000") || resumen.contains("5,000,000") || resumen.contains("5.000.000"));
        assertTrue(resumen.contains("2500000") || resumen.contains("2,500,000") || resumen.contains("2.500.000"));
        assertTrue(resumen.contains("FRECUENTE"));
        assertTrue(resumen.contains("ACTIVA"));
    }
    
    @Test
    @DisplayName("Test 20: Verificar cambio de estado después de compra")
    void testCambioEstadoDespuesCompra() {
        tarjeta.setSaldoActual(4920000);
        assertEquals("ALERTA", tarjeta.obtenerEstado()); // Cupo: 80000
        
        // Hacer una compra que deje el cupo en 5000
        assertTrue(tarjeta.realizarCompra(75000, "NACIONAL"));
        
        assertEquals(4995000, tarjeta.getSaldoActual(), DELTA);
        assertEquals("ALERTA", tarjeta.obtenerEstado()); // Cupo: 5000 (aún en alerta)
        
        // Hacer otra compra pequeña
        assertTrue(tarjeta.realizarCompra(5000, "NACIONAL"));
        
        assertEquals(5000000, tarjeta.getSaldoActual(), DELTA);
        assertEquals("BLOQUEADA", tarjeta.obtenerEstado()); // Cupo: 0
    }
    
    @Test
    @DisplayName("Test 21: Método central con tipo de compra inválido")
    void testTipoCompraInvalido() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            tarjeta.realizarCompra(100000, "INVALIDO");
        });
        
        assertTrue(exception.getMessage().contains("Tipo de compra no válido"));
        assertEquals(0, tarjeta.getSaldoActual(), DELTA);
        assertEquals(0, tarjeta.getTransaccionesMes());
    }
}